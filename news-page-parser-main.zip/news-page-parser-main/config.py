settings = {
    'hours_step': 1
}
